<?php

namespace App\Http\Controllers;

use App\Models\Status;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class WeatherController extends Controller
{
    /**
     * Gets Current weather updates for the passes location in request
     */
    public function get_weather(Request $request){
        $client = new Client();
        if(auth()->user()==null){
            return response()->json(["message"=>"Un Authorized User","status"=>Status::$UNAUTHORIZED],403);
        }
        try{
            //create a guzzle client object to be sent to the weather api
            $response = $client->get(env("WEATHER_API_URL"),[
                'query'=>[
                    "key"=>env("WEATHER_API_KEY"),
                    "q"=>$request["location"]
                ]
            ]);
            $statusCode = $response->getStatusCode();
            if ($statusCode!=200){
                return response()->json(["message"=>"There was an error connecting","status"=>Status::$ERROR],$statusCode);
            }
            //data from api
            $data = $response->getBody()->getContents();
            return response()->json(["message"=>$data,"status"=>Status::$SUCCESS]);
        }catch(Exception $e){
            //incase there was no connection to the api url
            return response()->json(["message"=>"Could not fetch data. Try again sometime","status"=>Status::$INTERNAL_ERROR],500);
        }
    }
}
