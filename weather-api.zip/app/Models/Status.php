<?php
namespace App\Models;
class Status
{
    static $SUCCESS = "success";
    static $ERROR = "error";
    static $UNAUTHORIZED = "error";
    static $INTERNAL_ERROR = "internal_error";
}
